﻿namespace Tests.ImproveTest
{
    /// <summary>
    /// The type of car
    /// 
    /// DO NOT MODIFY THIS CLASS
    /// </summary>
    public enum CarType
    {
        Sedan,
        Hatchback,
        Coupe,
        PickupTruck
    }
}